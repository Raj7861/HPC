# Compile and run con_global.cu

run the Makefile using make command to compile con_global.cu 
use srun to run the con_global.cu executable.The executable name is global.Specify the number of nodes which is 1 and the time limit which is 10 minutes
Altogether the command for running will be srun -N1 -t 00:10:00 ./global 