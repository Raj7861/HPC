# Compile and run con_share.cu

run the Makefile using make command to compile con_share.cu 
use srun to run the con_share.cu executable.The executable name is share.Specify the number of nodes which is 1 and the time limit which is 10 minutes
Altogether the command for running will be srun -N1 -t 00:10:00 ./share 