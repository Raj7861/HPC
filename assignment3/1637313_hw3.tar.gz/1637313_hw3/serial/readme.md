# Compile and run convolution.cu

run the Makefile using make command to compile convolution.cu 
use srun to run the convolution.cu executable.The executable name is conv.Specify the number of nodes which is 1 and the time limit which is 10 minutes
Altogether the command for running will be srun -N1 -t 00:10:00 ./conv 